﻿using SADgui.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SADgui.ViewModels
{
    public class TargetViewModel : ViewModelBase
    {

        //variables to hold values for types
        private Target m_target;
        
        public TargetViewModel(Target target)
        {
            m_target = target;
        }

        public TargetViewModel()
        {
            
        }

        //SearchTarget function iterates through our current list has the launcher info, and the name to search.  If name is found
        //the targets coordinates are passed to the MissileLauncherViewModel for targeting and execution
        public void SearchTarget(ObservableCollection<TargetViewModel> targetList, MissileLauncherViewModel launcher, string name)
        {

            if (name.Length > 0)                                //if caller has entered a name to search 
            {
                for (int i = 0; i < targetList.Count; i++)      //iterate through our TargetList to search for target name if enteredValue is entered.
                {
                    if (name == targetList[i].Name)             //if the given name is on our targetList 
                    {
                        if (targetList[i].Friend == true)       //if he is a friend dont shoot and display message
                        {
                            MessageBox.Show("Sorry Captain, we don't permit friendly fire, yar!\n");
                        }
                        else if (targetList[i].Status == "Dead")
                        {
                            MessageBox.Show("Captain, this bloak is already looking dead to me! Nasty luck mate.\n");
                        }

                        else                                    //ortherwise he is an enemy fire on coordinates
                        {
                            
                            double tempX = targetList[i].CoordinatesX;
                            double tempY = targetList[i].CoordinatesY;
                            double tempZ = targetList[i].CoordinatesZ;

                            if (launcher != null)
                            {
                                launcher.Position(tempX, tempY, tempZ);
                            }


                            for (i = 0; i < targetList.Count; i++)      //iterate through our TargetList to search for target name if enteredValue is entered.
                            {
                                if (targetList[i].Name == name)
                                {
                                    targetList[i].Status = "Dead";
                                }
                            }
                        }
                    }
                }
            }
        }


        //returns the value of our score
        public int Score
        {
            get
            {
                return m_target.score;
            }

            set
            {
                m_target.score = value;
                OnPropertyChanged("score"); //may be lower case
            }
        }

        //Shows the value of Dead or Alive
        public string Status
        {
            get
            {
                return m_target.Status;
            }

            set
            {
                m_target.Status = value;
                OnPropertyChanged("Status"); //may be lower case
            }
        }

        //Shows the value of Friend or Foe
        public bool Friend
        {
            get
            {
                return m_target.isFriend;
            }

            set
            {
                m_target.isFriend = value;
                OnPropertyChanged("Status"); //may be lower case
            }
        }

        //Shows value of Z coordinate
        public double CoordinatesZ
        {
            get
            {
                return m_target.Z;

            }

            set
            {

                m_target.Z = value;
                OnPropertyChanged("Zcord");
            }
        }

        //Shows value of Z coordinate
        public int Flash
        {
            get
            {
                return m_target.flashTime;

            }

            set
            {

                m_target.flashTime = value;
                OnPropertyChanged("flashRate");
            }
        }

        //Shows value of Y coordinate
        public double CoordinatesY
        {
            get
            {
                return m_target.Y;

            }

            set
            {

                m_target.Y = value;
                OnPropertyChanged("Ycord");
            }
        }

        //Shows value of X coordinate
        public double CoordinatesX
        {
            get
            {
                return m_target.X;

            }

            set
            {

                m_target.X = value;
                OnPropertyChanged("Xcord");
            }
        }
        
        //Returns the target name
        public string Name
        {
            get
            {
                return m_target.Name;
            }

            set
            {

                m_target.Name = value;
                OnPropertyChanged("Name");
            }
        }
    }
}
