﻿using SADgui.Models;
using Second.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;


namespace SADgui.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        public event PropertyChangedEventHandler PropertyChanged;


        private MissileLauncherViewModel m_selectedLauncher;
        private LauncherTypes m_selectedType;
        private TargetViewModel m_targetView;
        private string m_path;
        private string m_nameToKill;

        
        public MainViewModel(IEnumerable<LauncherTypes> launchers)  
        {
            Targets = new ObservableCollection<TargetViewModel>();

            //Creates List type of available launchers passed in on App startup
            Launchers = new ObservableCollection<LauncherTypes>();
            foreach (var launcher in launchers)
            {
                Launchers.Add(launcher);
            }

            //Delegate Commands used for Binding
            ClearCommand = new DelegateCommand(ClearTarget);
            TargetCommand = new DelegateCommand(NewList);
            KillCommand = new DelegateCommand(SearchTarget);

            //used to pass function parameters that have to do with target managment
            m_targetView = new TargetViewModel();     
        }

        public ObservableCollection<LauncherTypes> Launchers { get; private set; }
        public ObservableCollection<TargetViewModel> Targets { get; private set; }

        //The ClearTarget function clears all target from list.
        public void ClearTarget()
        {
            Targets.Clear();
        }
        
        //The NewList function creates a list of Targets from a path entered by the user from Game window.
        private void NewList()
        {
            if (Targets != null)
            {
                Targets.Clear();
            }
            if (m_path != null)
            {
                if (!File.Exists(m_path))
                {
                    MessageBox.Show("Invalid File Path, please reenter selection.");
                }
                else
                {
                    var targets = targetFactory.Product(m_path);
                    foreach (var target in targets)
                    Targets.Add(new TargetViewModel(target));
                }
            }
        }

        //Function sets the name of Target we wish to focus
        public string ToKill
        {
            get
            {
                return m_nameToKill;
            }

            set
            {
                m_nameToKill = value;
                OnPropertyChanged("m_nameToKill");
            }
        }

        //Function to set users selection of file to open
        public string FilePath
        {
            get
            {
                return m_path;
            }

            set
            {
                m_path = value;
                OnPropertyChanged("m_path");
            }
        }

        //Function used to seek and kill target, pass in the Targetlist, currnetly selected missile Launcher,
        //and name of Target to seek.
        private void SearchTarget()
        {
            m_targetView.SearchTarget(Targets, m_selectedLauncher, m_nameToKill);
        }
                    
        //Gets the viewModel for Missile Launcher
        public MissileLauncherViewModel MissileLaunchers
        {
            get
            {
                return m_selectedLauncher;
            }
            private set
            {
                m_selectedLauncher = value;
                OnPropertyChanged("MissileLaunchers");
            }
        }

        //Selects the Launcher Type; Mock or Real
        public LauncherTypes SelectedType
        {
            get
            {
                return m_selectedType;
            }
            set
            {
                if (m_selectedType == value)
                    return;

                m_selectedType = value;
                var launcher = MissileLauncherFactory.Create(value);
                MissileLaunchers = new MissileLauncherViewModel(launcher);
            }
        }

        //ICommands to use in DelegateCommand class for Binding
        public ICommand ClearCommand { get; private set; }
        public ICommand TargetCommand { get; private set; }
        public ICommand KillCommand { get; private set; }       
    }

}
