﻿using SADgui.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;


namespace SADgui.ViewModels
{
    public class MissileLauncherViewModel : ViewModelBase
    {
        private IMissileLauncher m_launcher;

        //initial values for missile launceher, assuming fully loaded and in start position
        private int missiles = 4;       
        private double phi = 0;
        private double theta = 0;

        //Default constructor setting launcher
        public MissileLauncherViewModel(IMissileLauncher launcher)
        {

            m_launcher = launcher;

            //The below are definitions for DelegateCommand objects

            Action fire = FireMissiles;
            Action up = MoveUp;
            Action down = MoveDown;
            Action left = MoveLeft;
            Action right = MoveRight;
            Action reload = Reload;
            Action calibrate = Calibrate;

            FireCommand = new DelegateCommand(fire);
            UpCommand = new DelegateCommand(up);
            DownCommand = new DelegateCommand(down);
            LeftCommand = new DelegateCommand(left);
            RightCommand = new DelegateCommand(right);
            ReloadCommand = new DelegateCommand(reload);
            CalibrateCommand = new DelegateCommand(calibrate);


        }

        //Returns value for theta to Viewmodel
        public double Theta
        {
            get
            {
                return theta;
            }

            set
            {

                theta = value;
                OnPropertyChanged("theta");
            }
        }

        //Returns value for phi to ViewModel
        public double Phi
        {
            get
            {
                return phi;
            }

            set
            {

                phi = value;
                OnPropertyChanged("phi");
            }
        }

        //Retuns value for missiles to ViewModel
        public int Missiles
        {
            get
            {
                return missiles;
            }

            set
            {
                missiles = value;
                OnPropertyChanged("Missiles");
            }
        }

        //Returns missile Launcher to phi=0 and theta=0 position
        private void Calibrate()
        {
            m_launcher.command_reset();
            phi = 0;
            OnPropertyChanged("phi");
            theta = 0;
            OnPropertyChanged("theta");
        }

        //Reloads the misile launcher and returns missile count to 4
        private void Reload()
        {
            m_launcher.reload();
            missiles = 4;
            OnPropertyChanged("missiles");
        }

        //Manual control, will move missile launcher 1 degree to the right
        private void MoveRight()
        {
            m_launcher.command_Right(1);
            phi++;
            OnPropertyChanged("phi");
        }

        //Overloaded control for use by targeting system, will move right by value phi
        private void MoveRight(int m)
        {
            m_launcher.command_Right(m);
            phi++;
            OnPropertyChanged("phi");
        }

        //Manual control, will move missile launcher 1 degree to the left
        private void MoveLeft()
        {
            m_launcher.command_Left(1);
            phi--;
            OnPropertyChanged("phi");
        }

        //Overloaded control for use by targeting system, will move left by value phi
        private void MoveLeft(int m)
        {
            m_launcher.command_Left(m);
            phi--;
            OnPropertyChanged("phi");
        }

        //Manual control, will move missile launcher 1 degree down
        private void MoveDown(int m)
        {
            m_launcher.command_Down(m);
            if (theta > 0)
            {
                theta--;
                OnPropertyChanged("theta");
            }
        }

        //Overloaded control for use by targeting system, will move down by value theta
        private void MoveDown()
        {
            m_launcher.command_Down(1);
            if (theta > 0)
            {
                theta--;
                OnPropertyChanged("theta");
            }
        }

        //Manual control, will move missile launcher 1 degree up
        private void MoveUp()
        {
            m_launcher.command_Up(1);
            if (theta <= 21)
            {
                theta++;
                OnPropertyChanged("theta");
            }
        }

        //Overloaded control for use by targeting system, will move up by value theta
        private void MoveUp(int m)
        {
            m_launcher.command_Up(m);
            if (theta <= 21)
            {
                theta++;
                OnPropertyChanged("theta");
            }
        }

        //Will fire one misile
        private void FireMissiles()
        {
            m_launcher.command_Fire();
            if (missiles >= 1)
            {
                missiles--;
                OnPropertyChanged("missiles");
            }

        }

        //This function is called from the TargetViewModel to handel the Missile Launcher movment and fireing once a target
        //is determinied to be an enemy.  The function is set up to keep track on Phi and Theta as it attackes muliple targets
        public void Position(double x, double y, double z)
        {
            //create a value to store our phi, which is x,y left/right, and theta
            double radius = 0;
            double mPhi = 0;                        
            double mTheta = 0;



            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //http://www.learningaboutelectronics.com/Articles/Cartesian-rectangular-to-spherical-coordinate-converter-calculator.php#answer
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            radius = Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2) + Math.Pow(z, 2));  //cartetion product


            mTheta = (180 / Math.PI) * (Math.Acos(z / radius));       //calculating theta which is our up/down
            
            mPhi = (180 / Math.PI) * (Math.Atan(y / x));          //calculateing phi which is left/right
            
            if (z == 0)
            {
                mTheta = 0;
                
            }

            //converts to int because our missleLauncher only understands integers
            int t = Convert.ToInt32(mPhi);           
            int t2 = Convert.ToInt32(mTheta);

            //if entered value is less that zero it is a negative number and will move left.
            if (t <= phi)                         
            {
                double left = phi - t;
                int positive = Convert.ToInt32(left);
                positive = Math.Abs(positive);      //must take absolute value of number to enter into moveLeft function
                MoveLeft(positive);                 //missle launcher moves left by amount entered
                phi = phi - positive;
                OnPropertyChanged("phi");
            }

            //if entered value is greater that zero missile launcher will move right.
            else
            {
                double right = t - phi;
                int positive = Convert.ToInt32(right);
                positive = Math.Abs(positive);      //must take absolute value of number to enter into moveLeft function
                MoveRight(positive);                //if entered value is positive then we move right by amount entered
                phi = phi + positive;
                OnPropertyChanged("phi");
            }

            //if entered value is less that zero it is a negative number and will move down.
            if (t2 <= theta)
            {
                int temp2 = Convert.ToInt32(theta - t2);
                int positive = Math.Abs(temp2);
                MoveDown(positive);
                theta = theta - positive;
                OnPropertyChanged("theta");
            }

            //if entered value is greater that zero it is a positive number and will move up.
            else
            {
                int temp2 = Convert.ToInt32(t2 - theta);
                int positive = Math.Abs(temp2);
                MoveUp(positive);
                theta = theta + positive;
                OnPropertyChanged("theta");
            }

            //leaving this here for now but can remove if we need to manually fire.
            FireMissiles();
            
        }

        public ICommand FireCommand { get; set; }
        public ICommand UpCommand { get; private set; }
        public ICommand DownCommand { get; private set; }
        public ICommand LeftCommand { get; private set; }
        public ICommand RightCommand { get; private set; }
        public ICommand ReloadCommand { get; private set; }
        public ICommand CalibrateCommand { get; private set; }

    }


















    //    private IMissileLauncher m_launcher;

    //    public MissileLauncherViewModel(IMissileLauncher launcher)
    //    {
    //        m_launcher = launcher;
    //        FireCommand = new DelegateCommand(Fire);
    //    }

    //    public void Fire()
    //    {
    //        m_launcher.Fire();
    //    }

    //    public ICommand FireCommand { get; set; }
    //}
}
